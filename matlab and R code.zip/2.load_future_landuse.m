%load luh2 data from nc to mat

clear all
clc
cd('E:\code')%set working directory
%load data
lon=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','lon');
lat=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','lat');

urban_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','urban');
urban_p1(urban_p1>1)=nan;
urban_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','urban');
urban_p2(urban_p2>1)=nan;
urban_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','urban');
urban_p3(urban_p3>1)=nan;
urban_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','urban');
urban_p4(urban_p4>1)=nan;
urban_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','urban');
urban_p5(urban_p5>1)=nan;

c3ann_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','c3ann');
c3ann_p1(c3ann_p1>1)=nan;
c3ann_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','c3ann');
c3ann_p2(c3ann_p2>1)=nan;
c3ann_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','c3ann');
c3ann_p3(c3ann_p3>1)=nan;
c3ann_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','c3ann');
c3ann_p4(c3ann_p4>1)=nan;
c3ann_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','c3ann');
c3ann_p5(c3ann_p5>1)=nan;
c4ann_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','c4ann');
c4ann_p1(c4ann_p1>1)=nan;
c4ann_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','c4ann');
c4ann_p2(c4ann_p2>1)=nan;
c4ann_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','c4ann');
c4ann_p3(c4ann_p3>1)=nan;
c4ann_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','c4ann');
c4ann_p4(c4ann_p4>1)=nan;
c4ann_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','c4ann');
c4ann_p5(c4ann_p5>1)=nan;
c3per_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','c3per');
c3per_p1(c3per_p1>1)=nan;
c3per_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','c3per');
c3per_p2(c3per_p2>1)=nan;
c3per_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','c3per');
c3per_p3(c3per_p3>1)=nan;
c3per_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','c3per');
c3per_p4(c3per_p4>1)=nan;
c3per_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','c3per');
c3per_p5(c3per_p5>1)=nan;
c4per_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','c4per');
c4per_p1(c4per_p1>1)=nan;
c4per_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','c4per');
c4per_p2(c4per_p2>1)=nan;
c4per_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','c4per');
c4per_p3(c4per_p3>1)=nan;
c4per_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','c4per');
c4per_p4(c4per_p4>1)=nan;
c4per_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','c4per');
c4per_p5(c4per_p5>1)=nan;
c3nfx_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','c3nfx');
c3nfx_p1(c3nfx_p1>1)=nan;
c3nfx_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','c3nfx');
c3nfx_p2(c3nfx_p2>1)=nan;
c3nfx_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','c3nfx');
c3nfx_p3(c3nfx_p3>1)=nan;
c3nfx_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','c3nfx');
c3nfx_p4(c3nfx_p4>1)=nan;
c3nfx_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','c3nfx');
c3nfx_p5(c3nfx_p5>1)=nan;

cropland_p1=c3ann_p1+c4ann_p1+c3per_p1+c4per_p1+c3nfx_p1;
cropland_p2=c3ann_p2+c4ann_p2+c3per_p2+c4per_p2+c3nfx_p2;
cropland_p3=c3ann_p3+c4ann_p3+c3per_p3+c4per_p3+c3nfx_p3;
cropland_p4=c3ann_p4+c4ann_p4+c3per_p4+c4per_p4+c3nfx_p4;
cropland_p5=c3ann_p5+c4ann_p5+c3per_p5+c4per_p5+c3nfx_p5;

pastr_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','pastr');
pastr_p1(pastr_p1>1)=nan;
pastr_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','pastr');
pastr_p2(pastr_p2>1)=nan;
pastr_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','pastr');
pastr_p3(pastr_p3>1)=nan;
pastr_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','pastr');
pastr_p4(pastr_p4>1)=nan;
pastr_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','pastr');
pastr_p5(pastr_p5>1)=nan;

range_p1=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-IMAGE-ssp126-2-1-f_gn_2015-2100.nc','range');
range_p1(range_p1>1)=nan;
range_p2=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MESSAGE-ssp245-2-1-f_gn_2015-2100.nc','range');
range_p2(range_p2>1)=nan;
range_p3=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-AIM-ssp370-2-1-f_gn_2015-2100.nc','range');
range_p3(range_p3>1)=nan;
range_p4=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-GCAM-ssp434-2-1-f_gn_2015-2100.nc','range');
range_p4(range_p4>1)=nan;
range_p5=ncread('multiple-states_input4MIPs_landState_ScenarioMIP_UofMD-MAGPIE-ssp585-2-1-f_gn_2015-2100.nc','range');
range_p5(range_p5>1)=nan;

otherland_p1=1-urban_p1-cropland_p1-pastr_p1-range_p1;
otherland_p1(otherland_p1<0)=0;
otherland_p2=1-urban_p2-cropland_p2-pastr_p2-range_p2;
otherland_p2(otherland_p2<0)=0;
otherland_p3=1-urban_p3-cropland_p3-pastr_p3-range_p3;
otherland_p3(otherland_p3<0)=0;
otherland_p4=1-urban_p4-cropland_p4-pastr_p4-range_p4;
otherland_p4(otherland_p4<0)=0;
otherland_p5=1-urban_p5-cropland_p5-pastr_p5-range_p5;
otherland_p5(otherland_p5<0)=0;

save luhdata.mat